export interface UserEnergyData {
    userId: string;
    timeStamp: string;
    energyConsumption: number;
}