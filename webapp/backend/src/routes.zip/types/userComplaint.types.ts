export interface UserComplaint {
    userId: string;
    complaintId: string;
    timeStamp: string;
    title: string;
    description: string;
    status: string;
}