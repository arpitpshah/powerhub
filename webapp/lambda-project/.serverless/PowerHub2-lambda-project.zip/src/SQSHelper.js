"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SQSHelper = void 0;
const aws_sdk_1 = require("aws-sdk");
const SNSHelper_1 = require("./SNSHelper");
class SQSHelper {
    constructor() {
        this.sqs = new aws_sdk_1.SQS();
        this.snsHelper = new SNSHelper_1.SNSHelper();
    }
    async deleteMessageFromQueue(queueUrl, receiptHandle) {
        try {
            const params = {
                QueueUrl: queueUrl,
                ReceiptHandle: receiptHandle,
            };
            await this.sqs.deleteMessage(params).promise();
        }
        catch (error) {
            console.error('Error deleting message from SQS:', error);
        }
    }
}
exports.SQSHelper = SQSHelper;
