"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SNSHelper = void 0;
const aws_sdk_1 = require("aws-sdk");
class SNSHelper {
    constructor() {
        this.sns = new aws_sdk_1.SNS();
    }
    async isUserConfirmed(topicArn, userEmail) {
        var _a;
        try {
            const subscriptions = await this.sns.listSubscriptionsByTopic({ TopicArn: topicArn }).promise();
            const subscription = (_a = subscriptions.Subscriptions) === null || _a === void 0 ? void 0 : _a.find((sub) => sub.Protocol === 'email' && sub.Endpoint === userEmail);
            if ((subscription === null || subscription === void 0 ? void 0 : subscription.SubscriptionArn) !== 'PendingConfirmation') {
                return true;
            }
            return false;
        }
        catch (error) {
            console.error('Error checking user confirmation status:', error);
            return false;
        }
    }
    async sendSNSNotification(snsTopicArn, complaint) {
        try {
            const message = `Complaint ID: ${complaint.complaintId}\nComplaint Registered: ${complaint.title}\nComplaint Description: ${complaint.description}\nThank you for your patience. Your complaint will be addressed shortly.`;
            const subject = 'Complaint Registration Confirmation';
            await this.sns.publish({
                Message: message,
                Subject: subject,
                TopicArn: snsTopicArn,
            }).promise();
        }
        catch (error) {
            console.error('Error sending SNS notification:', error);
        }
    }
}
exports.SNSHelper = SNSHelper;
