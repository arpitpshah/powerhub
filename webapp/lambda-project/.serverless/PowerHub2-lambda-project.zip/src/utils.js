"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPreviousMonthDateRange = exports.isPeakHour = exports.formatDateForDisplay = exports.calculateCost = void 0;
function calculateCost(units, hour) {
    const peakRate = 0.20;
    const offPeakRate = 0.10;
    return isPeakHour(hour) ? units * peakRate : units * offPeakRate;
}
exports.calculateCost = calculateCost;
function formatDateForDisplay(dateString) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
}
exports.formatDateForDisplay = formatDateForDisplay;
function isPeakHour(hour) {
    return hour >= 17 && hour < 21;
}
exports.isPeakHour = isPeakHour;
function getPreviousMonthDateRange() {
    const now = new Date();
    const firstDayOfPreviousMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const lastDayOfPreviousMonth = new Date(now.getFullYear(), now.getMonth(), 0);
    return { firstDayOfPreviousMonth, lastDayOfPreviousMonth };
}
exports.getPreviousMonthDateRange = getPreviousMonthDateRange;
